const screens=["intro","pocket","rocketScreen","cardScreen"];
function showScreen(id){screens.forEach(s=>document.getElementById(s).classList.toggle("active",s===id));}
document.getElementById("begin").addEventListener("click",()=>{showScreen("pocket");});
document.getElementById("launch").addEventListener("click",()=>{showScreen("rocketScreen");});
document.getElementById("reveal").addEventListener("click",()=>{showScreen("cardScreen");launchFirework(innerWidth/2,innerHeight/3);});

const sender=document.getElementById("sender"),receiver=document.getElementById("receiver");
document.getElementById("makeCard").addEventListener("click",()=>{
 const name=sender.value.trim(),to=receiver.value.trim();
 if(!name){sender.focus();alert("पहले अपना नाम लिखें।");return;}
 document.getElementById("greetTitle").textContent=to?`${to} जी, आपके लिए एक प्यारा संदेश`:"आपको और आपके परिवार को";
 document.getElementById("signature").textContent=`सप्रेम शुभकामनाएँ — ${name}`;
 launchFirework(innerWidth/2,innerHeight/2);
});
document.getElementById("share").addEventListener("click",()=>{
 const from=sender.value.trim();if(!from){sender.focus();alert("पहले अपना नाम लिखें और कार्ड बनाएँ।");return;}
 const to=receiver.value.trim();
 const msg=`${to?to+" जी, ":""}${document.getElementById("greetTitle").textContent}\nदीपावली की हार्दिक शुभकामनाएँ! 🪔\nमाँ लक्ष्मी और श्री गणेश की कृपा आप पर बनी रहे।\nसप्रेम शुभकामनाएँ — ${from}`;
 window.open("https://wa.me/?text="+encodeURIComponent(msg),"_blank","noopener,noreferrer");
});

// Original generated tones: browsers require a user click before sound starts.
let audio=null,musicTimer=null,musicOn=false;
function ctx(){const A=window.AudioContext||window.webkitAudioContext;if(!A)return null;if(!audio)audio=new A();if(audio.state==="suspended")audio.resume();return audio;}
function note(freq,delay=0,dur=.6,wave="sine",vol=.04){const c=ctx();if(!c)return;const t=c.currentTime+delay,o=c.createOscillator(),g=c.createGain();o.type=wave;o.frequency.value=freq;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+.03);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+dur+.03);}
document.getElementById("bell").addEventListener("click",()=>[880,1174,1568].forEach((f,i)=>note(f,i*.025,1.6,"sine",.05/(i+1))));
document.getElementById("music").addEventListener("click",e=>{
 if(musicOn){clearInterval(musicTimer);musicOn=false;e.currentTarget.textContent="♫ Music ON";return;}
 const melody=[523,659,784,659,587,698,880,698];let i=0;musicTimer=setInterval(()=>{note(melody[i%melody.length],0,.42,"sine",.025);i++;},480);musicOn=true;e.currentTarget.textContent="♫ Music OFF";
});

// Canvas fireworks
const canvas=document.getElementById("fx"),g=canvas.getContext("2d");let bits=[];
function size(){const d=Math.min(devicePixelRatio||1,2);canvas.width=innerWidth*d;canvas.height=innerHeight*d;g.setTransform(d,0,0,d,0,0)}addEventListener("resize",size);size();
function launchFirework(x,y){const colors=["#ffd35f","#ff6384","#fff0bd","#c6a6ff","#8fffd1"];for(let i=0;i<46;i++){let a=Math.random()*Math.PI*2,s=1+Math.random()*3.4;bits.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:55,color:colors[Math.floor(Math.random()*colors.length)]});}}
function draw(){g.clearRect(0,0,innerWidth,innerHeight);bits=bits.filter(p=>p.life>0);for(const p of bits){p.x+=p.vx;p.y+=p.vy;p.vy+=.025;p.life--;g.globalAlpha=p.life/55;g.fillStyle=p.color;g.beginPath();g.arc(p.x,p.y,2,0,Math.PI*2);g.fill();}g.globalAlpha=1;requestAnimationFrame(draw)}draw();
function randomFirework(){launchFirework(40+Math.random()*(innerWidth-80),40+Math.random()*(innerHeight*.5));}
setInterval(randomFirework,1900);
document.getElementById("fireworks").addEventListener("click",()=>{for(let i=0;i<4;i++)setTimeout(randomFirework,i*220);});
document.getElementById("lights").addEventListener("click",()=>{document.querySelector(".mini-diya i")?.animate([{transform:"scale(1)"},{transform:"scale(1.35)"},{transform:"scale(1)"}],{duration:650});launchFirework(innerWidth/2,innerHeight*.7);});
